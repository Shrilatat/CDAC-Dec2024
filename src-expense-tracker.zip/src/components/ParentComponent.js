import React, { Component } from 'react'
import ChildComponent from './ChildComponent'

class ParentComponent extends Component{
   render(){
    return (
      <div>
          <h3>ParentComponent</h3>
          <ChildComponent cname="Yuvraj"/>
      </div>
    )
   }
}

export default ParentComponent