var Person = (props)=>{
    return <h2>Hi {props.pname}, i am {props.age} years old</h2>
}

export default Person