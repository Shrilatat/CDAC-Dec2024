import { useState } from "react"

const styles = {
    heading: {
        fontWeight: 'bold',
        fontSize: '25px',
        color: "green",
        textAlign: "center",
    },
    subHeading: {
        fontWeight: 'bold',
        fontSize: '25px',
        textAlign: "center",
    },
    form: {
        backgroundColor: '#fff',
        padding: '20px',
        borderRadius: '8px',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
        width: '100%',
        maxWidth: '400px',
        margin: '0 auto',
    },
    input: {
        width: '100%',
        padding: '12px',
        marginBottom: '12px',
        border: '1px solid #ccc',
        borderRadius: '10px',
        fontSize: '16px',
        transition: 'border-color 0.2s ease',
    },
    button: {
        backgroundColor: 'green',
        color: '#fff',
        fontWeight: 'bold',
        fontSize: '16px',
        padding: '12px',
        border: 'none',
        borderRadius: '10px',
        cursor: 'pointer',
        width: '40%',
        transition: 'opacity 0.2s ease',
    },
};

let SimpleFormWithInBuiltStyle = () => {

    let [uname, setUname] = useState("")

    let unameHandler = (event) => {
        setUname(event.target.value)
    }

    let submitHandler = (event) => {
        event.preventDefault();
        console.log("Hello", uname)
        setUname("")
    }

    return (
        <div>
            <h1 style={styles.heading}>Welcome to forms</h1>
            <h3 style={styles.subHeading}>User Input </h3>
            <form onSubmit={submitHandler} style={styles.form}>
                Username : <input onChange={unameHandler}
                    style={styles.input}
                    value={uname} /><br />
                <input type="submit" style={{ ...styles.button}}/>
            </form>
        </div>
    )
}

export default SimpleFormWithInBuiltStyle