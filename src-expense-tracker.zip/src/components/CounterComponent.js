import React, { Component } from 'react'

class CounterComponent extends Component {
    //let [counter, setCounter] = useState(0)
    constructor(){
      super()
      this.state={counter:0}
    }

    btnHandler = ()=>{
        console.log("btn clicked")
        //setCounter(counter + 1)
        this.setState({counter : this.state.counter + 1})
    }
    render(){
      return (
        <div>
            <h2>Counter : {this.state.counter}</h2>
            <button onClick={this.btnHandler}>Increment Count</button>
        </div>
      )
    }
}
export default CounterComponent