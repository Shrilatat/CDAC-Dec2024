import React, { Component } from 'react'

class ChildComponent extends Component {
  render(){
    return (
      <div>
          <h3>ChildComponent - {this.props.cname}</h3>
      </div>
    )
  }
}

export default ChildComponent