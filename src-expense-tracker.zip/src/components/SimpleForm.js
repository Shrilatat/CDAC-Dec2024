import React, { useState } from 'react'

const SimpleForm = () => {

    let [name, setName] = useState("")
    let [email, setEmail] = useState("")

   let nameHandler = (event)=>{
      setName(event.target.value)
   }

   let emailHandler = (event)=>{
    setEmail(event.target.value)
 }

   let submitHandler = (e)=>{
      e.preventDefault()
      console.log("Hello", name, " your email is", email)
      setName("")
   }

  return (
    <div>
        <form onSubmit={submitHandler}>
            Username : <input onChange={nameHandler} value={name}/> <br />
            Email : <input type="email" onChange={emailHandler} value={email}/> <br />
            <input type="submit" className="btn btn-primary"/>
        </form>
    </div>
  )
}

export default SimpleForm