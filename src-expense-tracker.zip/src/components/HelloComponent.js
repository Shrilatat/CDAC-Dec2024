import React, { Component } from 'react'
/*
const HelloComponent = () => {
  return (
    <div>HelloComponent</div>
  )
}*/

class HelloComponent extends Component{
    render(){
        return (
            <div>HelloComponent as a class </div>
          )
    }
}

export default HelloComponent