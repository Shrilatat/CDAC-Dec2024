import logo from './logo.svg';
import AddTodo from './components/AddTodo';
import TodoList from './components/TodoList';
import CounterComponent from './components/CounterComponent';

function App() {
  return (
    <div className="container">
      <div className="row">
        <div className="col col-sm-6">
          <AddTodo />
        </div>
        <div className="col col-sm-6">
          <CounterComponent />
        </div>
      </div>
      <div className="row"></div>
      <div className="row">
        <div className="col col-sm-12">
          <TodoList />
        </div>
      </div>
    </div>
  );
}

export default App;


