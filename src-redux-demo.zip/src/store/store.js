import { configureStore } from "@reduxjs/toolkit";
import userReducer from "../features/userslice";
import todoReducer from "../features/todoslice"
import counterReducer from "../features/counterslice"

export const store = configureStore({
    reducer:{
        user:userReducer,
        todo:todoReducer,
        counter:counterReducer
    } 
})
//we are passing a collection of reducers in configureStore()