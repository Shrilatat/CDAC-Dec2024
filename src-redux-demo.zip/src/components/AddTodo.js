import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import { addTodo } from '../features/todoslice'

const AddTodo = () => {

    const [input, setInput] = useState("")

    const dispatch = useDispatch()

    let submitHandler = (e) => {
        e.preventDefault()
        dispatch(addTodo(input))
        setInput("")
    }

    return (
        <form onSubmit={submitHandler}>
            <div className="form-group">
                <input placeholder="Enter a Todo..."
                    value={input} className="form-control"
                    onChange={e => setInput(e.target.value)} />
            </div>
            <button type="submit" className='btn btn-danger'>
                Add Todo</button>
        </form>
    )
}
export default AddTodo
