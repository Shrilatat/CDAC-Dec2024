import { useDispatch, useSelector } from "react-redux"
import { decrement, increment } from "../features/counterslice"

let CounterComponent = ()=>{

    const count = useSelector(state => state.counter.value)
    const dispatch = useDispatch()

    return (
        <div>
            <h3>Counter : {count}  </h3>
            <button onClick={()=>dispatch(increment())} 
                    className="btn btn-primary">
                    Increment</button>&nbsp;&nbsp;
            <button onClick={()=>dispatch(decrement())} 
                    className="btn btn-primary">
                    Decrement</button>
        </div>
    )
}
export default CounterComponent