import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { removeTodo } from '../features/todoslice'

const TodoList = () => {
    const list = useSelector(state => state.todo) //to fetch all todos from store
    const dispatch = useDispatch() //to dispatch removeTodo action

    return (
        <div>
            <hr />
            <h3>TodoList</h3>
            <table className="table table-striped">
                <thead className="thead-info">
                   <tr><th>ToDo</th><th>&nbsp;</th></tr>
                </thead>
                <tbody>
                    {list.todos.map(todo=>(
                        <tr key={todo.id}>
                            <td>{todo.text}</td>
                            <td><button onClick={()=>dispatch(removeTodo(todo.id))} 
                                        className='btn btn-warning'>&times;</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
                </table>
        </div>
    )
}
export default TodoList
