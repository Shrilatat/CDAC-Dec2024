// component/NavBar.js

import { NavLink } from "react-router-dom";

const NavBar = () => {
  return (
    <nav>
      <br></br>
      <ul className="list-inline">
        <li className="list-inline-item">
          <NavLink to="/" className="btn btn-primary">Home</NavLink>
        </li>
        <li className="list-inline-item">
          <NavLink to="/courseList" className="btn btn-primary">Course List</NavLink>
        </li>
        <li className="list-inline-item">
          <NavLink to="/courseForm" className="btn btn-primary">Add Course</NavLink>
        </li>
      </ul>
    </nav>
  );
};

export default NavBar;