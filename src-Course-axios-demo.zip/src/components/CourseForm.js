import { Fragment, useState } from "react"
import { useNavigate } from 'react-router-dom'
import CourseService from "./service/CourseService";


const CourseForm = (props) => {

    //its a hook which gives access to navigate object used for changing the url
    let navigate = useNavigate()
    
    let [formdetails, setformdetails] = useState({ id: "", name: "", desc: "" });

    let addCourse = () => {
        if (formdetails.id === "" || formdetails.name === "" || formdetails.desc === "") {
            alert("fields cannnot be blank");
            return;
        }
        CourseService.addCourse(formdetails)
            .then((result) => {
                //it will change the url to /table
                console.log(result);
                setformdetails({ emidpid: "", name: "", desc: "" });
                navigate("/courseList")
            })
            .catch(error => {
                console.log(error);
            });



    }
    return (
        <div>
            <form>
                <div className="form-group">
                    <label htmlFor="id">Course id</label>
                    <input className="form-control" id="id" name="id"
                        value={formdetails.id}
                        onChange={(event) => { setformdetails({ ...formdetails, id: event.target.value }) }}
                    />

                </div>
                <div className="form-group">
                    <label htmlFor="name">Course Name</label>
                    <input className="form-control" id="name" name="name"
                        value={formdetails.name}
                        onChange={(event) => { setformdetails({ ...formdetails, name: event.target.value }) }}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="desc">Course Desc</label>
                    <input className="form-control" id="desc" name="desc"
                        value={formdetails.desc}
                        onChange={(event) => { setformdetails({ ...formdetails, desc: event.target.value }) }}
                    />
                </div>
                <button type="button" className="btn btn-primary" onClick={addCourse}>Add Course</button>
            </form>
        </div>
    )
}

export default CourseForm;