import axios from 'axios';
const baseUrl = 'http://localhost:4000/course/courses'

class CourseService{
    
    getCourses(){
        return axios.get(baseUrl)
    }
    getById(id){
        return axios.get(baseUrl+"/"+id)
    }
    updateCourse(course){
        return axios.put(baseUrl+"/"+course.id,course)
    }
    addCourse(course){
       return axios.post(baseUrl,course)
    }
    deleteById(id){
        return axios.delete(baseUrl+"/"+id)
    }
}

export default new CourseService();